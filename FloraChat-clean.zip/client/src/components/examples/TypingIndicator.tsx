import { TypingIndicator } from "../TypingIndicator";

export default function TypingIndicatorExample() {
  return (
    <div className="p-4">
      <TypingIndicator />
    </div>
  );
}
